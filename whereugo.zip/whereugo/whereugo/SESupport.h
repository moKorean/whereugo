//
//  SESupport.h
//  whereugo
//
//  Created by mo.o on 2018. 5. 3..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>
//#import <CommonCrypto/CommonHMAC.h>

@interface SESupport : NSObject

//KeyChain 접근

/*
 @breif KeyChain에서 identifier(KEY)에 해당하는 스트링을 가져옵니다.
 */
+ (NSString *)getStringFromKeychainWithIdentifier:(NSString *)identifier;

/*
 @breif KeyChain에서 identifier(KEY)에 해당하는 데이터를 가져옵니다.
 */
+ (NSData *)getDataFromKeychainWithIdentifier:(NSString *)identifier;



/*
 @breif KeyChain에 identifier(KEY)에 스트링을 저장합니다. 이미 값이 있을경우 update 됩니다.
 */
+ (BOOL)createKeychainValue:(NSString *)value forIdentifier:(NSString *)identifier;

/*
 @breif KeyChain에 identifier(KEY)에 데이터를 저장합니다. 이미 값이 있을경우 update 됩니다.
 */
+ (BOOL)createKeychainValueData:(NSData *)value forIdentifier:(NSString *)identifie;



/*
 @breif KeyChain에 identifier(KEY)에 스트링을 업데이트합니다. create에서 처리 되므로 궂이 부를 필요는 없습니다.
 */
+ (BOOL)updateKeychainValue:(NSString *)value forIdentifier:(NSString *)identifier;

/*
 @breif KeyChain에 identifier(KEY)에 데이터를 업데이트합니다. create에서 처리 되므로 궂이 부를 필요는 없습니다.
 */
+ (BOOL)updateKeychainValueData:(NSData *)value forIdentifier:(NSString *)identifie;



/*
 @breif KeyChain에 identifier(KEY)에 해당하는 키밸류를 삭제합니다.
 */
+ (void)deleteItemFromKeychainWithIdentifier:(NSString *)identifier;

@end
