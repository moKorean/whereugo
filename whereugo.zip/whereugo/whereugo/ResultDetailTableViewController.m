//
//  ResultDetailTableViewController.m
//  whereugo
//
//  Created by mo.o on 2018. 5. 14..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import "ResultDetailTableViewController.h"
#import "SubUINavigationController.h"
#import "LibUtils.h"
#import "ViewController.h"


@interface ResultDetailTableViewController () {
    NSArray* finalData;
    BOOL hasPlaceName;
}

@end


@implementation ResultDetailTableViewController

@synthesize poiMeta;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    hasPlaceName = NO;

    _resultTableView.delegate = self;
    _resultTableView.dataSource = self;
    
    poiMeta = ((SubUINavigationController*)self.navigationController).poiMeta;
    
    NSLog(@"ResultDetailView vide did load!! data : %ld",[poiMeta count]);
    
    NSMutableArray* displayArray = [NSMutableArray new];

    NSEnumerator* keyEnum = [poiMeta keyEnumerator];

    for (NSString* key in keyEnum){
        [displayArray addObject:[poiMeta objectForKey:key]];
    }
    
    if (![LibUtils isStringNilOrEmpty:[[displayArray objectAtIndex:0] valueForKey:@"place_name"] ]){
        hasPlaceName = YES;
        
        NSSortDescriptor * descriptor = [[NSSortDescriptor alloc] initWithKey:@"place_name" ascending:YES];
        finalData = [displayArray sortedArrayUsingDescriptors:@[descriptor]];

    } else {
        NSSortDescriptor * descriptor = [[NSSortDescriptor alloc] initWithKey:@"address_name" ascending:YES];
        finalData = [displayArray sortedArrayUsingDescriptors:@[descriptor]];
    }
    
   

//    NSLog(@"finalData : %@",[finalData description]);

    
    // Uncomment the following line to preserve selection between presentations.
    self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;

    _resultTableView.rowHeight = 50;
    
    [_resultTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSLog(@"displayArray count %ld",[finalData count]);
    return [finalData count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
//    NSLog(@"cell for %@",[indexPath description]);
    static NSString *CellIdentifier = @"resultDetailCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    

    
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.imageView.image = nil;
    
    NSDictionary* metaObj = [finalData objectAtIndex:indexPath.row];
    
    cell.textLabel.text = hasPlaceName?[metaObj valueForKey:@"place_name"]:[metaObj valueForKey:@"address_name"];
    
    if (hasPlaceName){
        cell.detailTextLabel.text = [metaObj valueForKey:@"address_name"];
        cell.detailTextLabel.textColor = UIColorFromRGB(0x777777);
    }

    
//    cell.contentView.backgroundColor = [UIColor colorWithRed:1 green:1 blue:1 alpha:0.92f];
    
    
    //    UIBlurEffect* effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    //    UIVisualEffectView* blurView = [[UIVisualEffectView alloc] initWithEffect:effect];
    //
    //    blurView.frame = cell.contentView.frame;
    //
    ////    [cell.contentView addSubview:blurView];
    //    [cell.contentView insertSubview:blurView belowSubview:cell.contentView];
    
    cell.backgroundColor = [UIColor colorWithRed:1 green:1 blue:1 alpha:0];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    UITableViewCell *selectedCell = [tableView cellForRowAtIndexPath:indexPath];
    
    NSArray* temp = [poiMeta allKeysForObject:[finalData objectAtIndex:indexPath.row]];
    
    NSLog(@"selected id : %@", [temp lastObject]);
    
    [self dismissViewControllerAnimated:YES
                             completion:^{
                                 //
                                 NSLog(@"dissmiss");
                                 
                                 if ([[LibUtils getRootViewController] respondsToSelector:@selector(selectPoiItem:)]){
                                     [(ViewController*)[LibUtils getRootViewController] selectPoiItem:[[temp lastObject] longLongValue]];
                                 }
                             }];

    
    // Deselect the row.
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    return 50.f;
//}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)back:(id)sender{
    [self dismissViewControllerAnimated:YES
                             completion:^{
                                 //
                                 NSLog(@"dissmiss");
                                 
                             }];
}

@end
