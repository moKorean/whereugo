//
//  Network.m
//  whereugo
//
//  Created by mo.o on 2018. 5. 3..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import "Network.h"
#import "AFNetworking.h"
#import "LibUtils.h"
#import "SESupport.h"

@interface Network(){
    @private
    NSString* serverHost;
    
    @private
    NSString* accessToken;
    NSString* vin;
    
    BOOL isAuthSending;
    
    //for loading
    int maskSeq;
    CGRect windowSize;
    
    AFHTTPSessionManager* singleManager;
    AFNetworkReachabilityManager* reachManager;
}

- (BOOL)createNewSession;
- (void)responseFinalizer:(id)resultObject task:(NSURLSessionDataTask*)__task withStatusCode:(long)sCode;

@end

@implementation Network
@synthesize maskedView,spinner;

+ (instancetype)sharedNetwork{
    static Network* _sharedInstance = nil;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}


- (instancetype)init{
    self = [super init];
    if (self){
        
        serverHost = @"https://customer.bmwgroup.com";
        
        //네트워크 상태 매니저 시작
        reachManager = [AFNetworkReachabilityManager manager];
        
        maskSeq = 0;
        
        accessToken = vin = nil;
        
        isAuthSending = NO;
        
        [self startReachabilityStartWithCompletion:^{}];

        [self createNewSession];
        
    }
    
    return self;
}

- (void)startReachabilityStartWithCompletion:(nullable void (^)(void))completion {
    //상태 모니터링 시작
    [reachManager startMonitoring];
    
    [reachManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        NSLog(@"Network Reachability: %@", AFStringFromNetworkReachabilityStatus(status));
        
        if(status > 0 ){
            //네트웍 가능 //노티등을 쏴줄수 있어요~
            NSLog(@"Device Entered network(internet) accessible state.");
        } else {
            //네트웍 불가
            NSLog(@"Device Entered network(internet) inaccessible state.");
        }
        
    }];
}

- (nonnull AFHTTPSessionManager*)sessionManager{
    return singleManager;
}

- (void)setServerHost:(nonnull NSString*)host{
    serverHost = host;
   
}


- (BOOL)createNewSession{
    NSLog(@"Network - Create new session");

    //Session Configuration
    NSURLSessionConfiguration* sessionConfig = [NSURLSessionConfiguration defaultSessionConfiguration];
    [sessionConfig setSharedContainerIdentifier:@"com.lomohome.whereugo.sharedSession"];
    [sessionConfig setHTTPMaximumConnectionsPerHost:3];
    
    
    NSURL *url = nil;
    if (serverHost) {
        url = [NSURL URLWithString:serverHost];
    }
    
    //싱글턴 매니저 시작
    singleManager = [[AFHTTPSessionManager alloc] initWithBaseURL:url sessionConfiguration:sessionConfig];
    [[singleManager operationQueue] setMaxConcurrentOperationCount:3];
    
    
    //request Header setting
    singleManager.requestSerializer = [AFHTTPRequestSerializer serializer]; //[AFJSONRequestSerializer serializer];
//    [singleManager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    //기본 User-Agent 세팅
    [singleManager.requestSerializer setValue:@"curl/7.54.0" forHTTPHeaderField:@"User-Agent"];
    
    
    //response Header
    //HTTP parse error 가 날경우 일반 시리얼 라이즈를 사용하도록 변경
    NSArray *serializers = @[[AFJSONResponseSerializer serializer], [AFHTTPResponseSerializer serializer]];
    AFCompoundResponseSerializer *compoundResponseSerializer = [AFCompoundResponseSerializer compoundSerializerWithResponseSerializers:serializers];
    singleManager.responseSerializer = compoundResponseSerializer;
//    singleManager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];

    
    //completion callback 은 메인큐에서..
    dispatch_queue_t myQueue = dispatch_queue_create("com.lomohome.whereugo.networking", DISPATCH_QUEUE_CONCURRENT);
    [singleManager setCompletionQueue:myQueue];
    
    //redirect 요청을 받았을때 access token 을 캐치하기 위함
    [singleManager setTaskWillPerformHTTPRedirectionBlock:^NSURLRequest * _Nonnull(NSURLSession * _Nonnull session, NSURLSessionTask * _Nonnull task, NSURLResponse * _Nonnull response, NSURLRequest * _Nonnull request) {
        //redirect
        NSLog(@"will redirect!!!!%@",request.URL);
        
        //will redirect!!!!https://www.bmw-connecteddrive.com/app/static/external-dispatch.html#access_token=8kjT58u8yhbt0S6bzR8iFyyJ3Duua8qH&token_type=Bearer&expires_in=7199
        
        if ([[request.URL absoluteString] containsString:@"access_token"]){
            NSString* urlTemp = [request.URL absoluteString];
            
            urlTemp = [urlTemp substringFromIndex:NSMaxRange([urlTemp rangeOfString:@"access_token="])];
            
            urlTemp = [urlTemp substringToIndex:[LibUtils str:urlTemp indexOf:@"&"]];
            
            //redirect 로 access 토큰을 쏜다. 캐치!
            accessToken = [urlTemp copy];
        }
        
        return request;
    }];
    
    return YES;
}

- (NSURLSession*)session{
    return [singleManager session];
}

- (NSString*)accessToken{
    return accessToken;
}

- (nullable NSString*)sessionId{
    
    NSArray *cookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookiesForURL:[NSURL URLWithString:serverHost]];
    for (NSHTTPCookie *cookie in cookies){
        if ([cookie.name isEqualToString:@"SMSESSION"]){
            return cookie.value;
        }
    }
    
    return nil;
}

- (BOOL)isNetworkAvailable{
    return [reachManager isReachable];
}

- (BOOL)isDataNetworkAvailable{
    return [reachManager isReachableViaWWAN];
}

- (BOOL)isWifiAvailable{
    return [reachManager isReachableViaWiFi];
}



//response 받고 이것저것하고 네트워크 종료 노티를 쏴주기 위함.
- (void)responseFinalizer:(id)resultObject task:(NSURLSessionDataTask*)__task withStatusCode:(long)sCode{

#if TEST_MODE_TEST_CODE

    if (sCode == 0){
        NSLog(@"ServerHost not responsed! time out!");
        return;
    }
    
    if (((sCode>=200)&&(sCode<=299))){
        //success
        @try {
            NSLog(@"[😈NETWORK]->response SUCCESS[%ld]\n====================🎾SERVER MSG [%@] ====================\nresponse header : %@\nresponse body : %@\n==================================================",sCode,((NSMutableURLRequest*)[__task originalRequest]).URL,((NSHTTPURLResponse*)[__task response]).allHeaderFields,(resultObject!=nil)?[NSString stringWithCString:[[resultObject description] cStringUsingEncoding:NSASCIIStringEncoding] encoding:NSNonLossyASCIIStringEncoding]:@"SERVER RESPONSE ERROR : result Object is null"); // RESULT : %@ ,[resultObject description]
            
//            NSString * responseS = [[NSString alloc] initWithData:resultObject encoding:NSUTF8StringEncoding];
//            NSLog(@"origin : %@",responseS);
            

        } @catch (NSException *exception) {
            NSLog(@"[😈NETWORK]->response SUCCESS but parse error [%ld]\n====================🎾🔴SERVER MSG [%@]====================\nexception : %@\n==================================================",sCode,((NSMutableURLRequest*)[__task originalRequest]).URL,exception);
        }
        
    } else {
        //fail
        @try {
            
            if (resultObject != nil){
                NSError* err = (NSError*)resultObject;
                NSString* ErrorResponse = [[NSString alloc] initWithData:(NSData *)err.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
                NSLog(@"[😈NETWORK]->response FAIL[%ld]\n==================🔴SERVER ERR MSG [%@]==================\nresponse header : %@\nerror response : %@\n==================================================",sCode,((NSMutableURLRequest*)[__task originalRequest]).URL,((NSHTTPURLResponse*)[__task response]).allHeaderFields,ErrorResponse);
            } else {
                NSLog(@"[😈NETWORK]->response FAIL[%ld]\n==================🔴SERVER ERR MSG ==================\nNO ERROR OBJECT",sCode);
            }
            
        } @catch (NSException *exception) {
            NSLog(@"[😈NETWORK]->response 🔴FAIL and parse error🔴\n==================🔴SERVER ERR MSG [%@]==================\nexception : %@",((NSMutableURLRequest*)[__task originalRequest]).URL,exception);
        }
       
    }
    
    #endif

}

#pragma mark - public method
/**
 * progress 필요없으면 nil로...
 */
- (nullable NSURLSessionDataTask *)requestUrlConnectionWithMethod:(NetworkMethod)method
                                                              url:(nonnull NSString*)url
                                                       parameters:(nullable NSDictionary *)parameters
                                                          success:(nullable void (^)(NSDictionary* _Nonnull responseDictionary, NSURLSessionDataTask* _Nullable task))success
                                                          failure:(nullable void (^)(NSDictionary* _Nullable errResponseDictionary, NSError* _Nonnull error, long httpStatusCode, NSURLSessionDataTask* _Nullable task))failure
                                                         progress:(nullable void (^)(NSProgress* _Nullable progress))progress{

    
    NSURLSessionDataTask *_task;
    
    
    __block NSError *jsonError;
    __block NSDictionary *errJson = nil;
    
    
    switch (method) {
        case GET:{
            
            
            _task = [singleManager GET:url parameters:parameters progress:progress success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                
                [self responseFinalizer:responseObject task:[task copy] withStatusCode:(long)((NSHTTPURLResponse*)task.response).statusCode];

                success((NSDictionary*)responseObject, [task copy]);
                
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                
                [self responseFinalizer:error task:[task copy] withStatusCode:(long)((NSHTTPURLResponse*)task.response).statusCode];
                
                if (![LibUtils isStringNilOrEmpty:error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey]]){
                    
                    errJson = [NSJSONSerialization JSONObjectWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] options:NSJSONReadingMutableContainers error:&jsonError];
                    
                }
                
                failure(errJson, error, (long)((NSHTTPURLResponse*)task.response).statusCode, task);
            }];
        }
            break;

        case POST:{
            
            
            _task = [singleManager POST:url parameters:parameters progress:progress success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                
                [self responseFinalizer:responseObject task:[task copy] withStatusCode:(long)((NSHTTPURLResponse*)task.response).statusCode];

                
                success((NSDictionary*)responseObject, [task copy]);
                
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                
                [self responseFinalizer:error task:[task copy] withStatusCode:(long)((NSHTTPURLResponse*)task.response).statusCode];
                
                if (![LibUtils isStringNilOrEmpty:error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey]]){
                    
                    errJson = [NSJSONSerialization JSONObjectWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] options:NSJSONReadingMutableContainers error:&jsonError];
                    
                }
                
                failure(errJson, error, (long)((NSHTTPURLResponse*)task.response).statusCode, task);
                
            }];
            
            /*
             task = [singleManager POST:url parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
             //body
             
             if(imageData)
             {
             [formData appendPartWithFileData:imageData  name:@"param_name" fileName:@"filename.jpg" mimeType:@"image/jpeg"];
             }
             
             
             } progress:progress success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
             success(task, responseObject, (long)((NSHTTPURLResponse*)task.response).statusCode);
             } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
             failure(task, error, (long)((NSHTTPURLResponse*)task.response).statusCode);
             }];
             */
            
        }
            break;
        /*
        case DELETE:{
            
            _task = [singleManager DELETE:url parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                
                [self networkResultLogger:responseObject task:task withStatusCode:(long)((NSHTTPURLResponse*)task.response).statusCode];
                
                success((NSDictionary*)responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                
                [self networkResultLogger:error task:task withStatusCode:(long)((NSHTTPURLResponse*)task.response).statusCode];
                
                failure(task, error, (long)((NSHTTPURLResponse*)task.response).statusCode);
            }];
            
        }
            break;
         */
            
        default:
            
            NSLog(@"non allowed method : %@",ST_NetworkMethodStr(method));
            _task = nil;
            
            NSMutableDictionary* details = [NSMutableDictionary dictionary];
            [details setValue:[NSString stringWithFormat:@"non allowd method : %@",ST_NetworkMethodStr(method)] forKey:NSLocalizedDescriptionKey];
            NSError *error = [NSError errorWithDomain:@"moSDKerror" code:9999 userInfo:details];
            
            failure(@{@"status":[NSString stringWithFormat:@"%ld",(long)[error code]],
                      @"msg":[details valueForKey:NSLocalizedDescriptionKey]},error,0,nil);
            
            
            break;
    }
    
#if TEST_MODE_TEST_CODE
    NSURLSessionDataTask *task = [_task copy];
    
    if (task != nil){
        
        //allHTTPHeaderFields 를 한줄에 여러 파라메터랑 같이 쓰게 되면 간헐적으로 죽을때가 있음.
        //https://github.com/Alamofire/Alamofire/issues/513
        
        NSString* ___method,*___url;
        ___method = ((NSMutableURLRequest*)[task originalRequest]).HTTPMethod;
        ___url = ((NSMutableURLRequest*)[task originalRequest]).URL.absoluteString;
        NSDictionary* ___headerFields = [NSDictionary dictionaryWithDictionary:((NSMutableURLRequest*)[task currentRequest]).allHTTPHeaderFields];
        NSLog(@"[😈NETWORK]-> %lu's request [%@:%@]\nrequest header : %@\nparameters : %@",(unsigned long)task.taskIdentifier ,___method,___url,___headerFields,parameters);
        
        if (![LibUtils isStringNilOrEmpty:serverHost]){
            
            //checking cookies
            NSArray *cookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookiesForURL:((NSMutableURLRequest*)[task originalRequest]).URL];
            NSDictionary *sheaders = [NSHTTPCookie requestHeaderFieldsWithCookies:cookies];
            
            
            if (sheaders != nil)
                NSLog(@"Current Cookies when request : %@",sheaders);
            
        }
        
    }
#endif

    return _task;
    
}

- (nullable NSURLSessionDataTask *)requestUrlConnectionWithMethod:(NetworkMethod)method
                                                      requestType:(RequestType)rType
                                                              url:(nonnull NSString*)url
                                                       parameters:(nullable NSDictionary *)parameters
                                             customRequestHeaders:(nullable NSDictionary*)customReqHeaders
                                                          success:(nullable void (^)(NSDictionary* _Nonnull responseDictionary, NSURLSessionDataTask* _Nullable task))success
                                                          failure:(nullable void (^)(NSDictionary* _Nullable errResponseDictionary, NSError* _Nonnull error, long httpStatusCode, NSURLSessionDataTask* _Nullable task))failure
                                                         progress:(nullable void (^)(NSProgress* _Nullable progress))progress{
    
    
    if (rType == JSON){
        singleManager.requestSerializer = [AFJSONRequestSerializer serializer];
    } else {
        singleManager.requestSerializer = [AFHTTPRequestSerializer serializer];
    }
    
    //custom request 를 세팅해서 쏩니다.
    if (customReqHeaders != nil){
        [customReqHeaders enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            [singleManager.requestSerializer setValue:obj forHTTPHeaderField:key];
        }];
    }
    
    NSURLSessionDataTask *_task = [self requestUrlConnectionWithMethod:method
                                                                   url:url
                                                            parameters:parameters
                                                               success:success
                                                               failure:failure
                                                              progress:progress];
    
    //쏘고 난뒤에 custom request 를 삭제합니다.
    
    if (customReqHeaders != nil){
        [customReqHeaders enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            [singleManager.requestSerializer setValue:nil forHTTPHeaderField:key];
        }];
    }
    
    
    return _task;
    
    
}



//로그아웃시 각종 세션키 삭제와 세션을 없애버림
- (void)sessionInvalidate{
    
    dispatch_semaphore_t sem = dispatch_semaphore_create(0); //block 을 sync 하기 위하여 세마포어 세팅
    
    //쿠키 삭제
    NSArray *cookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookiesForURL:[NSURL URLWithString:serverHost]];
    for (NSHTTPCookie *cookie in cookies){
        [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
    }
    
    //각종 키 삭제
    [singleManager.session invalidateAndCancel]; //NSURLSession invalidate
    
    singleManager = nil; //싱글매니져 삭제
    
    [SESupport deleteItemFromKeychainWithIdentifier:bID];
    [SESupport deleteItemFromKeychainWithIdentifier:bPW];
    
    if ([self createNewSession]){
        dispatch_semaphore_signal(sem); //세마포어 시그널 줘서 계속 진행하게 함
    }
    
    dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30 * NSEC_PER_SEC))); //여기부터 30초 기다림
    
}



-(void)loadingStart{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        NSLog(@"loading start inapp : maskSeq 0 = %d",maskSeq);
        
        if (self.maskedView == nil && maskSeq == 0){
            NSLog(@"we make loading screen");
            //화면스피너 셋팅. 로딩중을 표시하기 위함.
            windowSize = [[UIScreen mainScreen] bounds];
            
            if (windowSize.size.width > windowSize.size.height){
                windowSize = CGRectMake(0, 0, windowSize.size.width, windowSize.size.width);
            } else {
                windowSize = CGRectMake(0, 0, windowSize.size.height, windowSize.size.height);
            }
            
            NSLog(@"windowSize = %f, %f",windowSize.size.width,windowSize.size.height);
            
            self.maskedView = [[UIView alloc] initWithFrame:windowSize];
            self.maskedView.backgroundColor = [UIColor blackColor];
            self.maskedView.alpha = 0.5f;
            
            [[self getRootViewController].view addSubview:self.maskedView];
            NSLog(@"KEY WINDOW MASK 추가 성공");
            
            self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
            [self.spinner setCenter:CGPointMake([[UIScreen mainScreen] bounds].size.width/2.0, [[UIScreen mainScreen] bounds].size.height/2.0)]; //화면중간에 위치하기위한 포인트.
            [[self getRootViewController].view addSubview:self.spinner];
            NSLog(@"KEY WINDOW SPINNER 추가 성공");
            
            [self.spinner startAnimating];
            maskSeq++;
            
            //10초가 지나면 네트웍 오류로 취소 시킨다.
            //[NSTimer scheduledTimerWithTimeInterval:10.0f target:self selector:@selector(terminateTransaction) userInfo:nil repeats:NO];
        } else {
            NSLog(@"already exist loading screen");
        }
    });
    
    
}


-(void)loadingEnd{
    
    NSLog(@"loading end inapp : maskSeq 1 = %d",maskSeq);
    
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.maskedView != nil && maskSeq == 1){
            self.maskedView.hidden = YES;
            [self.spinner stopAnimating];
            
            [self.spinner removeFromSuperview];
            [self.maskedView removeFromSuperview];
            
            self.spinner = nil;
            self.maskedView = nil;
            maskSeq--;
        }
    });
    
}


#pragma mark apis

- (void)openLoginView{
    UIAlertController* alertController = [UIAlertController
                                          alertControllerWithTitle:@"BMW Connected"
                                          message:@"로그인 정보는 안전하게 키체인에 저장됩니다"
                                          preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField)
     {
         textField.placeholder = @"ID";
         textField.clearButtonMode = UITextFieldViewModeWhileEditing;
         if ([SESupport getStringFromKeychainWithIdentifier:bID] != nil){
             textField.text = [SESupport getStringFromKeychainWithIdentifier:bID];
         }
     }];
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField)
     {
         textField.placeholder = @"Password";
         textField.secureTextEntry = YES;
     }];
    
    
    UIAlertAction *actionCancel = [UIAlertAction
                                   actionWithTitle:@"취소"
                                   style:UIAlertActionStyleCancel
                                   handler:nil];
    
    
    
    UIAlertAction *actionOK = [UIAlertAction
                               actionWithTitle:@"로그인"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   UITextField *_id = alertController.textFields.firstObject;
                                   UITextField *_pw = alertController.textFields.lastObject;
                                   
                                   if ([LibUtils isStringNilOrEmpty:[_id text]]){
                                       [self alert:@"ID를 입력해주세요." completion:^(UIAlertAction *action) {
                                           [self openLoginView];
                                       }];
                                       return;
                                   }
                                   
                                   if ([LibUtils isStringNilOrEmpty:[_pw text]]){
                                       [self alert:@"Password를 입력해주세요." completion:^(UIAlertAction *action) {
                                           [self openLoginView];
                                       }];
                                       return;
                                   }

                                   
                                   [self saveInformationIntoKeyChanin:[_id text] pw:[_pw text]];
                               }];
    
    [alertController addAction:actionCancel];
    [alertController addAction:actionOK];
    
    [[self getRootViewController] presentViewController:alertController animated:YES completion:^{
        if (![LibUtils isStringNilOrEmpty:[alertController.textFields.firstObject text]])
            [alertController.textFields.lastObject becomeFirstResponder];
    }];
}

-(void)saveInformationIntoKeyChanin:(NSString*)_id pw:(NSString*)_pw{
    [SESupport createKeychainValue:_id forIdentifier:bID];
    [SESupport createKeychainValue:_pw forIdentifier:bPW];
    
    [self authToBmw];
}

- (void)authToBmw{
    
    if ([SESupport getStringFromKeychainWithIdentifier:bID] == nil || [SESupport getStringFromKeychainWithIdentifier:bPW] == nil){
        
        NSLog(@"not found bmw information in keychain");
        //keychain 에 정보 없음
        [self openLoginView];
        return;
        
    }
    

    if (isAuthSending){
        NSLog(@"auth sending... reborted");
        return;
    }
    
    isAuthSending = YES;
    
    [[Network sharedNetwork] requestUrlConnectionWithMethod:POST requestType:NORMAL url:@"/gcdm/oauth/authenticate" parameters:
     @{@"client_id":@"dbf0a542-ebd1-4ff0-a9a7-55172fbfce35",
       @"redirect_uri":@"https://www.bmw-connecteddrive.com/app/static/external-dispatch.html",
       @"response_type":@"token",
       @"scope":@"authenticate_user fupo",
       @"locale":@"KR-ko",
       @"username":[SESupport getStringFromKeychainWithIdentifier:bID],
       @"password":[SESupport getStringFromKeychainWithIdentifier:bPW]}
     
                                       customRequestHeaders:
     @{@"Origin":@"https://customer.bmwgroup.com",
       @"Upgrade-Insecure-Requests":@"1",
       @"Accept":@"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
       @"Cache-Control":@"max-age=0",
       @"Referer":@"https://customer.bmwgroup.com"} success:^(NSDictionary * _Nonnull responseDictionary, NSURLSessionDataTask* _Nullable task) {
           //
           NSLog(@"auth success : %@",[self accessToken]);
           
           if ([self accessToken] == nil){
               isAuthSending = NO;

               [self openLoginView];
           } else {
               NSLog(@"bundle vin : %@",[SESupport getStringFromKeychainWithIdentifier:bVIN]);
               
               if ([SESupport getStringFromKeychainWithIdentifier:bVIN] == nil){
                   
                   [[Network sharedNetwork] requestUrlConnectionWithMethod:GET requestType:NORMAL
                                                                       url:@"/api/me/vehicles/v2?all=true&brand=BM"
                                                                parameters:nil
                                                      customRequestHeaders:
                    @{@"authorization":[@"Bearer " stringByAppendingString:accessToken],
                      @"Origin":@"https://www.bmw-connecteddrive.kr",
                      @"Referer":@"https://www.bmw-connecteddrive.kr",
                      @"Accept-Language":@"ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
                      @"Accept":@"application/json, text/plain, */*"
                      } success:^(NSDictionary * _Nonnull responseDictionary, NSURLSessionDataTask* _Nullable task) {
                          
                          NSLog(@"cars success : %@",responseDictionary);
                          
                          vin = [[responseDictionary valueForKey:@"vin"] objectAtIndex:0];

                          [SESupport createKeychainValue:vin forIdentifier:bVIN];
                          
                          NSLog(@"vin : [%@]",vin);
                          isAuthSending = NO;
                          
                      } failure:^(NSDictionary * _Nullable errResponseDictionary, NSError * _Nonnull error, long httpStatusCode, NSURLSessionDataTask * _Nullable task) {
                          
                          NSLog(@"cars fail : %@",errResponseDictionary);
                          isAuthSending = NO;
                          [self openLoginView];
                          
                      } progress:nil];
                   
                   
               } else {
                   vin = [SESupport getStringFromKeychainWithIdentifier:bVIN];
                   isAuthSending = NO;
               }

           }
           
        } failure:^(NSDictionary * _Nullable errResponseDictionary, NSError * _Nonnull error, long httpStatusCode, NSURLSessionDataTask * _Nullable task) {
           NSLog(@"auth fail : %@",errResponseDictionary);
           isAuthSending = NO;
           [self openLoginView];
       } progress:nil];

}

-(void)sendToCarSbj:(NSString*)sbj Msg:(NSString*)msg Lat:(NSString*)lat lng:(NSString*)lng{
    
    [self loadingStart];
    
    [[Network sharedNetwork] requestUrlConnectionWithMethod:POST requestType:JSON url:@"/api/vehicle/myinfo/v1" parameters:
     @{@"vins":@[vin],
       @"message":msg,
       @"subject":sbj,
       @"lat":lat,
       @"lng":lng}
     
                                       customRequestHeaders:
     @{@"Origin":@"https://www.bmw-connecteddrive.kr",
       @"Accept-Language":@"ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
       @"authorization":[@"Bearer " stringByAppendingString:accessToken],
       @"Content-Type":@"application/json;charset=UTF-8",
       @"Accept":@"application/json, text/plain, */*",
       @"Referer":@"https://www.bmw-connecteddrive.kr"} success:^(NSDictionary * _Nonnull responseDictionary, NSURLSessionDataTask* _Nullable task) {
           //success
           NSLog(@"send to car success : %@",responseDictionary);
           
           [self loadingEnd];
           
       } failure:^(NSDictionary * _Nullable errResponseDictionary, NSError * _Nonnull error, long httpStatusCode, NSURLSessionDataTask * _Nullable task) {
           //fail
           NSLog(@"send to car fail");
           
           [self loadingEnd];

           [self alert:@"로그인이 안되었습니다." completion:^(UIAlertAction *action) {
               [[Network sharedNetwork] authToBmw];;
           }];
           
           
       } progress:nil];
}


- (UIViewController*)getRootViewController{
    //get rootview
    UIViewController *topRootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (topRootViewController.presentedViewController)
    {
        topRootViewController = topRootViewController.presentedViewController;
    }
    
    return topRootViewController;
}

- (void)alert:(NSString*)_msg completion:(nullable void (^)(UIAlertAction* action))completion{
    UIAlertController *alertView = [UIAlertController alertControllerWithTitle:@"앗!"
                                                                       message:_msg
                                                                preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *actionCancel = [UIAlertAction
                                   actionWithTitle:@"확인"
                                   style:UIAlertActionStyleCancel
                                   handler:completion];
    
    [alertView addAction:actionCancel];
    
    [[self getRootViewController] presentViewController:alertView animated:YES completion:nil];
}

- (BOOL)isReadyToSendToCar{
    if (accessToken == nil || vin == nil){
        return NO;
    } else {
        return YES;
    }
}

@end
