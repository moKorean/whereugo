//
//  ViewController.h
//  whereugo
//
//  Created by mo.o on 2018. 5. 3..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <DaumMap/MTMapView.h>
#import <DaumMap/MTMapReverseGeoCoder.h>
#import <CoreLocation/CoreLocation.h>
#import "Network.h"

@interface ViewController : UIViewController <MTMapViewDelegate, UITextFieldDelegate, MTMapReverseGeoCoderDelegate, UITableViewDelegate, UITableViewDataSource, CLLocationManagerDelegate>

@property (strong, nonatomic) MTMapView *mapView;

@property (strong, nonatomic) IBOutlet UIView* baseView;

@property (strong, nonatomic) IBOutlet UIButton *pasteBtn;
@property (strong, nonatomic) IBOutlet UIButton *currentBtn;

@property (strong, nonatomic) IBOutlet UISegmentedControl *mapTypeControl;
@property (strong, nonatomic) IBOutlet UISegmentedControl *searchTypeControl;

@property (strong, nonatomic) IBOutlet UITextField *searchText;
@property (strong, nonatomic) IBOutlet UITableView *suggestResultView;

@end

