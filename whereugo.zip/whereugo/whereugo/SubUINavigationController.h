//
//  SubUINavigationController.h
//  whereugo
//
//  Created by mo.o on 2018. 5. 14..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubUINavigationController : UINavigationController

@property (strong, nonatomic) NSMutableDictionary* poiMeta;

@end
