//
//  ViewController.m
//  whereugo
//
//  Created by mo.o on 2018. 5. 3..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import "ViewController.h"
#import "LibUtils.h"
#import "SESupport.h"

#import "SubUINavigationController.h"

@interface ViewController (){
    MTMapReverseGeoCoder* reverseGeoCoder;
    NSString* reversedAdress;
    
    NSURLSessionDataTask* suggestTask;
    NSMutableArray* suggestKeywords;
    
    NSInteger selectedPOItag;
    NSMutableDictionary* poiMeta;
    
    CLLocationManager* locationManager;
    CLLocation* currentLocation;
    BOOL initialMove;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    reversedAdress = nil;
    
    initialMove = NO;

    [MTMapView setMapTilePersistentCacheEnabled:YES];
    
    _mapView = [[MTMapView alloc] initWithFrame:CGRectMake(_baseView.frame.origin.x, _baseView.frame.origin.y , _baseView.frame.size.width, _baseView.frame.size.height)];
    _mapView.delegate = self;
    _mapView.baseMapType = MTMapTypeStandard;
    _mapView.useHDMapTile = YES;
    _mapView.showCurrentLocationMarker = NO;

    [_baseView addSubview:_mapView];
    
    _searchText.delegate = self;
    _searchText.returnKeyType = UIReturnKeySearch;
    _searchText.autocorrectionType = UITextAutocorrectionTypeNo;
    [_searchText addTarget:self action:@selector(textFieldChanged) forControlEvents:UIControlEventEditingChanged];

    suggestKeywords = [NSMutableArray new];
    _suggestResultView.dataSource = self;
    _suggestResultView.delegate = self;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(getClipboardString:)
                                                 name:UIApplicationDidBecomeActiveNotification object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyUp)
                                                 name:UIApplicationDidBecomeActiveNotification object:nil];

    //처음에 한번 요청 하고 10분에 한번씩 위치 업데이트 요청
    [self startStandardUpdates];
    [NSTimer scheduledTimerWithTimeInterval:(60.0f * 10) target:self selector:@selector(startStandardUpdates) userInfo:nil repeats:YES];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [suggestKeywords removeAllObjects];
    
    [_mapView removeAllPOIItems];
    
}

- (void)mapView:(MTMapView*)mapView singleTapOnMapPoint:(MTMapPoint*)mapPoint{
    [self keyDown];
}

- (void)mapView:(MTMapView*)mapView longPressOnMapPoint:(MTMapPoint*)mapPoint{
    [self keyDown];
    
    [self startReverseGeocoding:mapPoint];
    
    NSLog(@"long : %f, %f",mapPoint.mapPointGeo.latitude,mapPoint.mapPointGeo.longitude);
    
    if ([_mapView findPOIItemByTag:50000] != nil){
        [_mapView removePOIItem:[_mapView findPOIItemByTag:50000]];
    }
    
    MTMapPOIItem* poiItem1 = [MTMapPOIItem poiItem];
    poiItem1.itemName = [LibUtils isStringNilOrEmpty:reversedAdress]?@"여기":reversedAdress;
    poiItem1.mapPoint = [MTMapPoint mapPointWithGeoCoord:MTMapPointGeoMake(mapPoint.mapPointGeo.latitude,mapPoint.mapPointGeo.longitude)];
    poiItem1.markerType = MTMapPOIItemMarkerTypeRedPin;
    poiItem1.showAnimationType = MTMapPOIItemShowAnimationTypeDropFromHeaven;
    poiItem1.draggable = YES;
    poiItem1.showDisclosureButtonOnCalloutBalloon = NO;
    poiItem1.tag = 50000; //[NSInteger parseIn];
    
    [_mapView addPOIItem:poiItem1];
    
//    [self sendToCarPopSubj:nil lat:[NSString stringWithFormat:@"%f",mapPoint.mapPointGeo.latitude]  lng:[NSString stringWithFormat:@"%f",mapPoint.mapPointGeo.longitude] ];
    
}


- (IBAction)changeMapType:(id)sender{
    UISegmentedControl* sendO = (UISegmentedControl*)sender;
    
    if ([sendO selectedSegmentIndex] == 0){
        //0 기본
        [_mapView setBaseMapType:MTMapTypeStandard];
    } else if ([sendO selectedSegmentIndex] == 1){
        //1 위성
        [_mapView setBaseMapType:MTMapTypeSatellite];
    } else {
        //2 섞어
        [_mapView setBaseMapType:MTMapTypeHybrid];
    }

}


/**
 * [POI Item] 단말 사용자가 POI Item 아이콘(마커) 위에 나타난 말풍선(Callout Balloon)을 터치한 경우 호출된다.
 * @param mapView MTMapView 객체
 * @param poiItem 말풍선이 터치된 POI Item 객체
 * @see MTMapPOIItem
 */
- (void)mapView:(MTMapView*)mapView touchedCalloutBalloonOfPOIItem:(MTMapPOIItem*)poiItem{
    NSLog(@"touchedCalloutBalloonOfPOIItem %@ %f %f",poiItem.itemName,poiItem.mapPoint.mapPointGeo.latitude,poiItem.mapPoint.mapPointGeo.longitude);

    selectedPOItag = poiItem.tag;
    
    [self sendToCarPopSubj:poiItem.itemName
                       lat:[NSString stringWithFormat:@"%f",poiItem.mapPoint.mapPointGeo.latitude]
                       lng:[NSString stringWithFormat:@"%f",poiItem.mapPoint.mapPointGeo.longitude]];
    
}

/**
 * [POI Item] 단말 사용자가 길게 누른후(long press) 끌어서(dragging) 위치 이동 가능한 POI Item의 위치를 이동시킨 경우 호출된다.
 * 이동가능한 POI Item을 Draggable POI Item이라 한다.
 * @param mapView MTMapView 객체
 * @param poiItem 새로운 위치로 이동된 Draggable POI Item 객체
 * @param newMapPoint 이동된 POI Item의 위치에 해당하는 지도 좌표
 * @see MTMapPOIItem
 */
- (void)mapView:(MTMapView*)mapView draggablePOIItem:(MTMapPOIItem*)poiItem movedToNewMapPoint:(MTMapPoint*)newMapPoint{

    [self startReverseGeocoding:newMapPoint];
    
    [_mapView deselectPOIItem:poiItem];
    
}

- (void)startStandardUpdates{
    // Create the location manager if this object does not
    // already have one.
    if (nil == locationManager)
        locationManager = [[CLLocationManager alloc] init];
    
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;

    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
        [locationManager requestWhenInUseAuthorization];
     
    [locationManager startUpdatingLocation];
    
    NSLog(@"location start!");
}

// Delegate method from the CLLocationManagerDelegate protocol.
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
    // If it's a relatively recent event, turn off updates to save power.
    currentLocation = [locations lastObject];
    
    NSLog(@"did update location! : latitude %+.6f, longitude %+.6f\n",currentLocation.coordinate.latitude,currentLocation.coordinate.longitude);
    
    if (!initialMove){
        [self moveToCurrentLocationAndPin];
        initialMove = YES;
    }
    
    [locationManager stopUpdatingLocation];
}

-(IBAction)goCurrentLocation:(id)sender{
    
    /*
    // TODO: 설정 만들어서 키체인 키 다 날리도록 해야함.
    [SESupport deleteItemFromKeychainWithIdentifier:bVIN];
    [SESupport deleteItemFromKeychainWithIdentifier:bID];
    [SESupport deleteItemFromKeychainWithIdentifier:bPW];
    */
    
    initialMove = NO;
    [self startStandardUpdates];
    
}

-(void)moveToCurrentLocationAndPin{
    NSLog(@"go Current : latitude %+.6f, longitude %+.6f\n",
          currentLocation.coordinate.latitude,
          currentLocation.coordinate.longitude);
    
    MTMapPoint* mapPoint = [MTMapPoint mapPointWithGeoCoord:MTMapPointGeoMake(currentLocation.coordinate.latitude, currentLocation.coordinate.longitude)] ;
    
    [_mapView setMapCenterPoint:mapPoint zoomLevel:3 animated:YES];
    
    if ([_mapView findPOIItemByTag:60000] != nil){
        [_mapView removePOIItem:[_mapView findPOIItemByTag:60000]];
    }
    
    MTMapPOIItem* poiItem1 = [MTMapPOIItem poiItem];
    poiItem1.itemName = @"현위치";
    poiItem1.mapPoint = mapPoint;
    poiItem1.markerType = MTMapPOIItemMarkerTypeBluePin;
    poiItem1.showAnimationType = MTMapPOIItemShowAnimationTypeDropFromHeaven;
    poiItem1.draggable = NO;
    poiItem1.showDisclosureButtonOnCalloutBalloon = NO;
    poiItem1.tag = 60000; //[NSInteger parseIn];
    
    [_mapView addPOIItem:poiItem1];

}


-(void)pinCustomMTMapPoint:(MTMapPoint*)mapPoint tag:(NSInteger)tag markerType:(MTMapPOIItemMarkerType)markerType{
    [self keyDown];
    
    [self startReverseGeocoding:mapPoint];
    
    NSLog(@"pin : %f, %f",mapPoint.mapPointGeo.latitude,mapPoint.mapPointGeo.longitude);
    
    if ([_mapView findPOIItemByTag:tag] != nil){
        [_mapView removePOIItem:[_mapView findPOIItemByTag:tag]];
    }
    
    MTMapPOIItem* poiItem1 = [MTMapPOIItem poiItem];
    poiItem1.itemName = [LibUtils isStringNilOrEmpty:reversedAdress]?@"여기":reversedAdress;
    poiItem1.mapPoint = [MTMapPoint mapPointWithGeoCoord:MTMapPointGeoMake(mapPoint.mapPointGeo.latitude,mapPoint.mapPointGeo.longitude)];
    poiItem1.markerType = markerType;
    poiItem1.showAnimationType = MTMapPOIItemShowAnimationTypeDropFromHeaven;
    poiItem1.draggable = YES;
    poiItem1.showDisclosureButtonOnCalloutBalloon = NO;
    poiItem1.tag = tag; //[NSInteger parseIn];
    
    [_mapView addPOIItem:poiItem1];
}


-(void)getClipboardString:(id)sender{
    
    if (![LibUtils isStringNilOrEmpty:[UIPasteboard generalPasteboard].string]){
        _pasteBtn.hidden = NO;
    } else {
        _pasteBtn.hidden = YES;
    }
    
}

-(IBAction)pasteStr:(id)sender{
    if (![LibUtils isStringNilOrEmpty:[UIPasteboard generalPasteboard].string]){
        _searchText.text = [UIPasteboard generalPasteboard].string;
    }
}

#pragma mark keyboard

-(void)keyUp{
    [_searchText becomeFirstResponder];
}

-(void)keyDown{
    [_searchText resignFirstResponder];
}

-(void)textFieldChanged{    //addTarget 으로 텍스트 변경시마다 호출.
    NSLog(@"textFieldChanged : %@",_searchText.text);
    
    
    if ([LibUtils isStringNilOrEmpty:_searchText.text]){

        [self removeSuggestView];
        
    } else {

        if (suggestTask != nil){
            [suggestTask cancel];
            NSLog(@"%@ canceled",[suggestTask.currentRequest.URL absoluteString]);
        }

        suggestTask = [[Network sharedNetwork] requestUrlConnectionWithMethod:GET requestType:NORMAL
                                                                          url:@"http://acnf.tmap.co.kr:13131/TmapAutoCompleteServer/suggest"
                                                                   parameters:@{@"q":_searchText.text,
                                                                                @"s":@"tmap"} customRequestHeaders:nil
                       
                                                                      success:^(NSDictionary * _Nonnull responseDictionary, NSURLSessionDataTask * _Nullable task) {
                                                                          //success
                                                                          
                                                                          
                                                                          [suggestKeywords removeAllObjects];
                                                                          for (NSDictionary *doc in [[responseDictionary objectForKey:@"response"] objectForKey:@"suggestions"]) {
                                                                              NSLog(@"%@",[doc objectForKey:@"keyword"]);
                                                                              [suggestKeywords addObject:[doc objectForKey:@"keyword"]];
                                                                          }
                                                                          

                                                                          dispatch_async(dispatch_get_main_queue(), ^{

                                                                              if ([suggestKeywords count] > 0){
                                                                                  
                                                                                  _suggestResultView.hidden = NO;
                                                                                  [_suggestResultView reloadData];
                                                                                  
                                                                              } else {
                                                                                  [self removeSuggestView];
                                                                              }

                                                                          });


                                                                          
                                                                      } failure:^(NSDictionary * _Nullable errResponseDictionary, NSError * _Nonnull error, long httpStatusCode, NSURLSessionDataTask * _Nullable task) {
                                                                          //fail
                                                                          [self removeSuggestView];
                                                                          
                                                                      } progress:nil];

        
    }
    
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self showSuggestView];
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    [self removeSuggestView];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    // called when 'return' key pressed. return NO to ignore.
    
    NSLog(@"%@",textField.text);

    [self search:textField.text];
    
    [self keyDown];
    
    return YES;
}

#pragma mark search
- (void)search:(NSString*)query{

    [self removeSuggestView];
    
    NSString* apiUrl;
    
    if (_searchTypeControl.selectedSegmentIndex == 0){
        //명칭검색
        apiUrl = @"https://dapi.kakao.com/v2/local/search/keyword.json";
    } else {
        //주소검색
        apiUrl = @"https://dapi.kakao.com/v2/local/search/address.json";
    }
    
    [[Network sharedNetwork] requestUrlConnectionWithMethod:GET requestType:JSON url:apiUrl
                                                 parameters:
     @{@"y":[NSString stringWithFormat:@"%f",[_mapView mapCenterPoint].mapPointGeo.latitude]
       ,@"x":[NSString stringWithFormat:@"%f",[_mapView mapCenterPoint].mapPointGeo.longitude]
       ,@"query":query
       //    ,@"radius":@"20000"
       }
                                       customRequestHeaders:@{@"Authorization":[NSString stringWithFormat:@"KakaoAK %@",[[NSBundle mainBundle] objectForInfoDictionaryKey:@"KAKAO_RESTAPI_KEY"]]}
                                                    success:^(NSDictionary * _Nonnull responseDictionary, NSURLSessionDataTask * _Nullable task) {
                                                        
                                                        NSLog(@"검색 결과 : %@/%@",[[responseDictionary objectForKey:@"meta"] valueForKey:@"pageable_count"],[[responseDictionary objectForKey:@"meta"] valueForKey:@"total_count"]);
                                                        
                                                        
                                                        
                                                        NSMutableArray *pois = [NSMutableArray new];
                                                        
                                                        if (poiMeta == nil){
                                                            poiMeta = [NSMutableDictionary new];
                                                            
                                                        } else {
                                                            
//                                                            NSEnumerator* keyEnums = [poiMeta keyEnumerator];
//                                                            for (NSString* key in keyEnums){
//                                                                [_mapView removePOIItem:[_mapView findPOIItemByTag:[key longLongValue]]];
//                                                            }
                                                            
                                                            [poiMeta removeAllObjects];
                                                            
                                                        }
                                                        
                                                        [_mapView removeAllPOIItems];

                                                        
                                                        int tag = 5000;
                                                        for (NSDictionary *doc in [responseDictionary objectForKey:@"documents"]) {
                                                            
                                                            [poiMeta setObject:doc forKey:[NSNumber numberWithInt:tag]];
                                                            
                                                            MTMapPOIItem* poiItem1 = [MTMapPOIItem poiItem];
                                                            
                                                            if (_searchTypeControl.selectedSegmentIndex == 0){
                                                                //명칭검색
                                                                poiItem1.itemName = [doc valueForKey:@"place_name"];
                                                            } else {
                                                                //주소검색
                                                                poiItem1.itemName = [doc valueForKey:@"address_name"];
                                                            }
                                                            
                                                            poiItem1.mapPoint = [MTMapPoint mapPointWithGeoCoord:
                                                                                 MTMapPointGeoMake([[doc valueForKey:@"y"] floatValue],[[doc valueForKey:@"x"] floatValue])];
                                                            poiItem1.markerType = MTMapPOIItemMarkerTypeYellowPin;
                                                            poiItem1.showAnimationType = MTMapPOIItemShowAnimationTypeDropFromHeaven;
                                                            poiItem1.draggable = NO;
                                                            poiItem1.showDisclosureButtonOnCalloutBalloon = NO;
                                                            poiItem1.tag = tag; //[NSInteger parseIn];
                                                            
                                                            [pois addObject:poiItem1];
                                                            
                                                            tag++;
                                                        }
                                                        
                                                        dispatch_async(dispatch_get_main_queue(), ^{
                                                            if ([pois count] > 0){
                                                                [_mapView addPOIItems:pois];
                                                                [_mapView fitMapViewAreaToShowAllPOIItems];
                                                                _resultDetailBtn.hidden = NO;
                                                            } else {
                                                                _resultDetailBtn.hidden = YES;
                                                                
                                                                [self color:FAILED_COLOR Alert:^{
                                                                    [self keyUp];
                                                                }];
                                                                
                                                            }
                                                        });
                                                        
                                                        
                                                        
                                                    } failure:^(NSDictionary * _Nullable errResponseDictionary, NSError * _Nonnull error, long httpStatusCode, NSURLSessionDataTask * _Nullable task) {
                                                        //
                                                    } progress:nil];
}

#pragma mark send to car

- (void)sendToCarPopSubj:(NSString*)subjt lat:(NSString*)lat lng:(NSString*)lng{

    NSDictionary* gettedMeta;
    if (poiMeta != nil){
        gettedMeta = [poiMeta objectForKey:[NSNumber numberWithLong:selectedPOItag]];
    }

    if (gettedMeta == nil) gettedMeta = [NSDictionary new];
    
    UIAlertController* alertController = [UIAlertController
        alertControllerWithTitle:@"차량에 뭐라고 보낼까유"
        message:[gettedMeta valueForKey:@"address_name"]
        preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField)
     {
         textField.placeholder = @"타이틀";
         textField.clearButtonMode = UITextFieldViewModeWhileEditing;
         textField.text = subjt;
     }];
    
//    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField)
//     {
//         textField.placeholder = @"내용";
////         textField.secureTextEntry = YES;
//     }];
    

    //async
    reverseGeoCoder = [[MTMapReverseGeoCoder alloc] initWithMapPoint:[MTMapPoint mapPointWithGeoCoord:MTMapPointGeoMake([lat doubleValue], [lng doubleValue])] withDelegate:self withOpenAPIKey:[[NSBundle mainBundle] objectForInfoDictionaryKey:@"KAKAO_APP_KEY"]];
    reversedAdress = nil;
    [reverseGeoCoder startFindingAddress];
    
//    NSString* address = [MTMapReverseGeoCoder findAddressForMapPoint:MTMapPointGeoMake(37.537229,127.005515)                                                      withOpenAPIKey:[[NSBundle mainBundle] objectForInfoDictionaryKey:@"KAKAO_APP_KEY"]];
    
    UIAlertAction *actionCancel = [UIAlertAction
                                   actionWithTitle:@"취소"
                                   style:UIAlertActionStyleCancel
                                   handler:nil];
    
    
    
    UIAlertAction *actionOK = [UIAlertAction
                               actionWithTitle:@"전송"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   UITextField *subj = alertController.textFields.firstObject;
//                                   UITextField *msg = alertController.textFields.lastObject;
                                   
                                   [self processInputWithSubject:[subj text] Message:reversedAdress lat:lat lng:lng];
                               }];
    
    [alertController addAction:actionCancel];
    [alertController addAction:actionOK];
    
    NSLog(@"tel : %@",[gettedMeta valueForKey:@"phone"]);
    
    if (![LibUtils isStringNilOrEmpty:[gettedMeta valueForKey:@"phone"]]){
        UIAlertAction *actionCall = [UIAlertAction
                                     actionWithTitle:@"전화"
                                     style:UIAlertActionStyleDestructive
                                     handler:^(UIAlertAction *action)
                                     {
                                         
                                             NSLog(@"tel : %@",[gettedMeta valueForKey:@"phone"]);
                                         NSString *phoneNumber = [@"tel://" stringByAppendingString:[gettedMeta valueForKey:@"phone"]];
                                         [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber] options:@{} completionHandler:^(BOOL success) {
                                             //
                                         }];
                                     }];
        [alertController addAction:actionCall];
    }
    
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void) processInputWithSubject:(NSString *)subj Message:(NSString *)msg lat:(NSString*)lat lng:(NSString*)lng{

    if ([Network sharedNetwork].isReadyToSendToCar){
        
        if ([LibUtils isStringNilOrEmpty:subj]) subj = @"사용자 지정 위치";
        if ([LibUtils isStringNilOrEmpty:msg]) msg = @"Powered by mo.o";
        
        [[Network sharedNetwork] sendToCarSbj:subj Msg:msg Lat:lat lng:lng];
        
        if ([_mapView findPOIItemByTag:selectedPOItag] != nil){
            [_mapView deselectPOIItem:[_mapView findPOIItemByTag:selectedPOItag]];
        }

        
    } else {
        UIAlertController *alertView = [UIAlertController alertControllerWithTitle:@"앗!"
                                                                                    message:@"로그인이 안되었습니다."
                                                                             preferredStyle:UIAlertControllerStyleAlert];

        UIAlertAction *actionCancel = [UIAlertAction
                                       actionWithTitle:@"확인"
                                       style:UIAlertActionStyleCancel
                                       handler:^(UIAlertAction *action){
                                           [[Network sharedNetwork] authToBmw];
                                       }];
        
        [alertView addAction:actionCancel];
                                            
        [self presentViewController:alertView animated:YES completion:nil];
        
    }

    
}


#pragma mark ReverseGeoCoder
- (void)startReverseGeocoding:(MTMapPoint*)mapPoint{
    reverseGeoCoder = [[MTMapReverseGeoCoder alloc] initWithMapPoint:mapPoint
                                                        withDelegate:self
                                                      withOpenAPIKey:[[NSBundle mainBundle] objectForInfoDictionaryKey:@"KAKAO_APP_KEY"]];
    reversedAdress = nil;
    [reverseGeoCoder startFindingAddress];
}

- (void)MTMapReverseGeoCoder:(MTMapReverseGeoCoder*)rGeoCoder foundAddress:(NSString*)addressString{
    NSLog(@"found!! : %@",addressString);
    reversedAdress = addressString;
    reverseGeoCoder = nil;
    
    if ([_mapView findPOIItemByTag:50000] != nil){
        [_mapView deselectPOIItem:[_mapView findPOIItemByTag:50000]];
        [_mapView findPOIItemByTag:50000].itemName = reversedAdress;
        [_mapView selectPOIItem:[_mapView findPOIItemByTag:50000] animated:YES];
    }

}

- (void)MTMapReverseGeoCoder:(MTMapReverseGeoCoder*)rGeoCoder failedToFindAddressWithError:(NSError*)error{
    NSLog(@"주소 못찾겠다 꾀꼬리");
    reverseGeoCoder = nil;
    reversedAdress = nil;
}


#pragma mark table view (suggest)
-(void)showSuggestView{
    if ([suggestKeywords count] > 0){
        _suggestResultView.hidden = NO;
    }
}

-(void)removeSuggestView{
    [suggestKeywords removeAllObjects];
    _suggestResultView.hidden = YES;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [suggestKeywords count];
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"suggestCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
 
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.imageView.image = nil;
    cell.textLabel.text = [suggestKeywords objectAtIndex:indexPath.row];
    
    cell.contentView.backgroundColor = [UIColor colorWithRed:1 green:1 blue:1 alpha:0.92f];
    
    
//    UIBlurEffect* effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
//    UIVisualEffectView* blurView = [[UIVisualEffectView alloc] initWithEffect:effect];
//    
//    blurView.frame = cell.contentView.frame;
//    
////    [cell.contentView addSubview:blurView];
//    [cell.contentView insertSubview:blurView belowSubview:cell.contentView];
    
    cell.backgroundColor = [UIColor colorWithRed:1 green:1 blue:1 alpha:0];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *selectedCell = [tableView cellForRowAtIndexPath:indexPath];
    [self search:selectedCell.textLabel.text];
    _searchText.text = selectedCell.textLabel.text;
    
    // Deselect the row.
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    [self removeSuggestView];
    [self keyDown];
    
}

#pragma mark segue
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    NSLog(@"prepareForSegue in (Main)ViewController : %@ ,%@",[segue identifier],[[segue destinationViewController] description]);

    if ([[segue identifier] isEqualToString:@"showResultDetailSegue"]) {
        
        SubUINavigationController *resultView = [segue destinationViewController];
        
        resultView.poiMeta = [poiMeta copy];

    }
    
}


-(void)selectPoiItem:(NSInteger)tag{
    MTMapPOIItem* selectedItem = [_mapView findPOIItemByTag:tag];
    [_mapView selectPOIItem:selectedItem animated:YES];
    [_mapView setMapCenterPoint:selectedItem.mapPoint zoomLevel:1 animated:YES];
    
}

-(void)color:(int)_color Alert:(nullable void (^)(void))completion{

    dispatch_async(dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:0.2f animations:^{
            _searchText.backgroundColor = UIColorFromRGB(_color);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.2f animations:^{
                _searchText.backgroundColor = UIColorFromRGB(0xFFFFFF);
            } completion:^(BOOL finished) {
                if (completion) completion();
            }];
        }];
        
    });
}

@end
