//
//  AppDelegate.h
//  whereugo
//
//  Created by mo.o on 2018. 5. 3..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
