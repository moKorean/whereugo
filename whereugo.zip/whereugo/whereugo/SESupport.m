//
//  SESupport.m
//  whereugo
//
//  Created by mo.o on 2018. 5. 3..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import "SESupport.h"

#if TARGET_IPHONE_SIMULATOR

    #import "LibUtils.h"

#endif

NSString *const APP_NAME = @"com.lomohome.whereugo.keychain";

@implementation SESupport


// *** NOTE *** This class is ARC compliant - any references to CF classes must be paired with a "__bridge" statement to
// cast between Objective-C and Core Foundation Classes.  WWDC 2011 Video "Introduction to Automatic Reference Counting" explains this.
// *** END NOTE ***
// 쿼리생성기
+ (NSMutableDictionary *)setupSearchDirectoryForIdentifier:(NSString *)identifier{
    
    // Setup dictionary to access keychain.
    NSMutableDictionary *searchDictionary = [[NSMutableDictionary alloc] init];
    // Specify we are using a password (rather than a certificate, internet password, etc).
    
    /*
     For a keychain item of class kSecClassGenericPassword, the primary key is the combination of  kSecAttrAccount and kSecAttrService.
     For a keychain item of class kSecClassInternetPassword, the primary key is the combination of kSecAttrAccount, kSecAttrSecurityDomain, kSecAttrServer, kSecAttrProtocol, kSecAttrAuthenticationType, kSecAttrPort and kSecAttrPath.
     For a keychain item of class kSecClassCertificate, the primary key is the combination of kSecAttrCertificateType, kSecAttrIssuer and kSecAttrSerialNumber.
     For a keychain item of class kSecClassKey, the primary key is the combination of kSecAttrApplicationLabel, kSecAttrApplicationTag, kSecAttrKeyType, kSecAttrKeySizeInBits, kSecAttrEffectiveKeySize, and the creator, start date and end date which are not exposed by SecItem yet.
     For a keychain item of class kSecClassIdentity I haven't found info on the primary key fields in the open source files, but as an identity is the combination of a private key and a certificate, I assume the primary key is the combination of the primary key fields for kSecClassKey and kSecClassCertificate.
     */
    
    [searchDictionary setObject:(__bridge id)kSecClassGenericPassword forKey:(__bridge id)kSecClass]; //Token 은 GenericPassword 타입으로 저장하도록 한다.
    // Uniquely identify this keychain accessor.
    [searchDictionary setObject:APP_NAME forKey:(__bridge id)kSecAttrService];
    
    // Uniquely identify the account who will be accessing the keychain.
    NSData *encodedIdentifier = [identifier dataUsingEncoding:NSUTF8StringEncoding];
    [searchDictionary setObject:encodedIdentifier forKey:(__bridge id)kSecAttrGeneric];
    [searchDictionary setObject:encodedIdentifier forKey:(__bridge id)kSecAttrAccount];
    
    
    //카뱅 키체인의 디폴트는 ThisDeviceOnly 이다.
    [searchDictionary setObject:(__bridge id)kSecAttrAccessibleWhenUnlocked forKey:(__bridge id)kSecAttrAccessible]; //kSecAttrAccessibleWhenUnlocked 범위를 디바이스에 패스코드 세팅된 디바이스로 제한.
    return searchDictionary;
}

+ (NSString *)getStringFromKeychainWithIdentifier:(NSString *)identifier
{
    NSData *valueData = [self getDataFromKeychainWithIdentifier:identifier];
    if (valueData) {
        NSString *value = [[NSString alloc] initWithData:valueData
                                                encoding:NSUTF8StringEncoding];
        return value;
    } else {
        return nil;
    }
}

+ (NSData *)getDataFromKeychainWithIdentifier:(NSString *)identifier
{
 
#if TARGET_IPHONE_SIMULATOR
    
    return [LibUtils userDefaultObjectForKey:identifier];
    
#else
    
    NSMutableDictionary *searchDictionary = [self setupSearchDirectoryForIdentifier:identifier];
    
    // Limit search results to one.
    [searchDictionary setObject:(__bridge id)kSecMatchLimitOne forKey:(__bridge id)kSecMatchLimit];
    
    // Specify we want NSData/CFData returned.
    [searchDictionary setObject:(__bridge id)kCFBooleanTrue forKey:(__bridge id)kSecReturnData];
    
    // Search.
    NSData *result = nil;
    CFTypeRef foundDict = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)searchDictionary, &foundDict);
    
    if (status == noErr) {
        result = (__bridge_transfer NSData *)foundDict;
    } else {
        result = nil;
    }
    
    return result;
    
#endif
    
}



+ (BOOL)createKeychainValue:(NSString *)value forIdentifier:(NSString *)identifier
{
    NSData *valueData = [value dataUsingEncoding:NSUTF8StringEncoding];
    return [self createKeychainValueData:valueData forIdentifier:identifier];
}

+ (BOOL)createKeychainValueData:(NSData *)value forIdentifier:(NSString *)identifier
{
    
#if TARGET_IPHONE_SIMULATOR
    
    [LibUtils setUserDefaultObject:value forKey:identifier];
    return YES;
    
#else
    
    NSMutableDictionary *dictionary = [self setupSearchDirectoryForIdentifier:identifier];
    [dictionary setObject:value forKey:(__bridge id)kSecValueData];
    
    // Protect the keychain entry so it's only valid when the device is unlocked.
    //setup 에서 ACL 세팅
    //    [dictionary setObject:(__bridge id)kSecAttrAccessibleWhenUnlockedThisDeviceOnly forKey:(__bridge id)kSecAttrAccessible]; //kSecAttrAccessibleWhenUnlocked 범위를 디바이스에 패스코드 세팅된 디바이스로 제한.
    // Add.
    OSStatus status = SecItemAdd((__bridge CFDictionaryRef)dictionary, NULL);
    NSLog(@"create Key chain = (0 is normal) %d",(int)status);
    
    // If the addition was successful, return. Otherwise, attempt to update existing key or quit (return NO).
    if (status == errSecSuccess) {
        return YES;
    } else if (status == errSecDuplicateItem){
        NSLog(@"duplicate item. update");
        return [self updateKeychainValueData:value forIdentifier:identifier];
    } else {
        return NO;
    }

#endif
    
}

+ (BOOL)updateKeychainValue:(NSString *)value forIdentifier:(NSString *)identifier
{

    NSData *valueData = [value dataUsingEncoding:NSUTF8StringEncoding];
    return [self updateKeychainValueData:valueData forIdentifier:identifier];
    
}

+ (BOOL)updateKeychainValueData:(NSData *)value forIdentifier:(NSString *)identifier
{

#if TARGET_IPHONE_SIMULATOR
    
    [LibUtils setUserDefaultObject:value forKey:identifier];
    return YES;
    
#else
    
    NSMutableDictionary *searchDictionary = [self setupSearchDirectoryForIdentifier:identifier];
    
    NSMutableDictionary *updateDictionary = [[NSMutableDictionary alloc] init];
    [updateDictionary setObject:value forKey:(__bridge id)kSecValueData];
    
    // Update.
    OSStatus status = SecItemUpdate((__bridge CFDictionaryRef)searchDictionary,
                                    (__bridge CFDictionaryRef)updateDictionary);
    
    if (status == errSecSuccess) {
        return YES;
    } else {
        return NO;
    }

    
#endif
    
}

+ (void)deleteItemFromKeychainWithIdentifier:(NSString *)identifier
{
    
#if TARGET_IPHONE_SIMULATOR
    [LibUtils removeUserDefaultObjectForKey:identifier];
#else
    NSMutableDictionary *searchDictionary = [self setupSearchDirectoryForIdentifier:identifier];
    
    //Delete.
    SecItemDelete((__bridge CFDictionaryRef)searchDictionary);
    
#endif
}

@end
