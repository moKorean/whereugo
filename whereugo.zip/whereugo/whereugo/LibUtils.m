//
//  LibUtils.m
//  whereugo
//
//  Created by mo.o on 2018. 5. 3..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import "LibUtils.h"
#import <UIKit/UIKit.h>

#import "Network.h"

#define FILENAME_LIB_SETTINGS_PLIST @"whereugo.bundle"

static char encodingTable[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

//시뮬레이터 검사
#if TARGET_OS_SIMULATOR
static BOOL isSimulator = YES;
#else
static BOOL isSimulator = NO;
#endif


@implementation LibUtils

#pragma mark - Utility

+ (int)str:(NSString*)source indexOf:(NSString *)text {
    NSRange range = [source rangeOfString:text];
    if ( range.length > 0 ) {
        return (int)range.location;
    } else {
        return -1;
    }
}


+ (BOOL)isRealDevice{
    return !isSimulator;
}

+ (NSString*)getOSMajorVer{
    return [[[[UIDevice currentDevice] systemVersion] componentsSeparatedByString:@"."] objectAtIndex:0];
}

+ (NSData*)dictionaryToData:(NSDictionary*)myDictionary{
    NSData *myData = [NSKeyedArchiver archivedDataWithRootObject:myDictionary];
    return myData;
}

+ (NSDictionary*)dataToDictionary:(NSData*)myData{
    NSDictionary *myDictionary = (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:myData];
    return myDictionary;
}

+(BOOL)isStringNilOrEmpty:(NSString*)aString {
    return !(aString && aString.length);
}

+ (NSString*)getTimeStr{
    
    NSDate *now = [NSDate date];
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];

    [dateFormat setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"]];
    [dateFormat setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:60*60*9]]; //GMT+9
    [dateFormat setTimeStyle:NSDateFormatterShortStyle];
    [dateFormat setAMSymbol:@""];
    [dateFormat setPMSymbol:@""];
    [dateFormat setDateFormat:@"yyyyMMddHHmmss"];
   
    NSString* formattedString = [dateFormat stringFromDate:now];
    if ([formattedString length] == 14){
        return formattedString;
    } else {
        return nil;
    }
}



//Hexa conv util
static inline char itoh(int i) {
    if (i > 9) return 'A' + (i - 10);
    return '0' + i;
}

+ (NSString *)NSDataToHex:(NSData *)data{
    NSUInteger i, len;
    unsigned char *buf, *bytes;
    
    len = data.length;
    bytes = (unsigned char*)data.bytes;
    buf = malloc(len*2);
    
    for (i=0; i<len; i++) {
        buf[i*2] = itoh((bytes[i] >> 4) & 0xF);
        buf[i*2+1] = itoh(bytes[i] & 0xF);
    }
    
    return [[NSString alloc] initWithBytesNoCopy:buf
                                          length:len*2
                                        encoding:NSASCIIStringEncoding
                                    freeWhenDone:YES];
}

unsigned char strToChar (char a, char b)
{
    char encoder[3] = {'\0','\0','\0'};
    encoder[0] = a;
    encoder[1] = b;
    return (char) strtol(encoder,NULL,16);
}

+ (NSData *) HexToNSData:(NSString*)hexString{
    const char * bytes = [hexString cStringUsingEncoding: NSUTF8StringEncoding];
    NSUInteger length = strlen(bytes);
    unsigned char * r = (unsigned char *) malloc(length / 2 + 1);
    unsigned char * index = r;
    
    while ((*bytes) && (*(bytes +1))) {
        *index = strToChar(*bytes, *(bytes +1));
        index++;
        bytes+=2;
    }
    *index = '\0';
    
    NSData * result = [NSData dataWithBytes: r length: length / 2];
    free(r);
    
    return result;
}

//base64 conv util
+ (NSString *)base64_encode_data:(NSData *)data{
    
    if (data == nil) return nil;
    
    const uint8_t* input = (const uint8_t*)[data bytes];
    NSInteger length = [data length];
    
    //    static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    
    NSMutableData* newdata = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    uint8_t* output = (uint8_t*)newdata.mutableBytes;
    
    NSInteger i;
    for (i=0; i < length; i += 3) {
        NSInteger value = 0;
        NSInteger j;
        for (j = i; j < (i + 3); j++) {
            value <<= 8;
            
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        NSInteger theIndex = (i / 3) * 4;
        output[theIndex + 0] =                    encodingTable[(value >> 18) & 0x3F];
        output[theIndex + 1] =                    encodingTable[(value >> 12) & 0x3F];
        output[theIndex + 2] = (i + 1) < length ? encodingTable[(value >> 6)  & 0x3F] : '=';
        output[theIndex + 3] = (i + 2) < length ? encodingTable[(value >> 0)  & 0x3F] : '=';
    }
    
    return [[NSString alloc] initWithData:newdata encoding:NSASCIIStringEncoding];
    
}

+ (NSData *)base64_decode:(NSString *)str{
    
    @try{
        NSData *data = [[NSData alloc] initWithBase64EncodedString:str options:NSDataBase64DecodingIgnoreUnknownCharacters];
        return data;
    }
    @catch(NSException *e){
        NSLog(@"error : %@", e.reason);
        return nil;
    }
    
}

#pragma mark - LibSetting 설정 파일
+ (BOOL)writeApplicationPlist:(id)plist toFile:(NSString *)fileName {
    
    NSError *error = nil;
    NSData *pData = [NSPropertyListSerialization dataWithPropertyList:plist format:NSPropertyListBinaryFormat_v1_0 options:NSPropertyListImmutable error:&error];
    
    if (!pData) {
        NSLog(@"%@", error);
        return NO;
    }
    return [self writeApplicationData:pData toFile:fileName];
}

+ (BOOL)writeApplicationData:(NSData *)data toFile:(NSString *)fileName {
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    if (!documentsDirectory) {
        NSLog(@"Documents directory not found!");
        return NO;
    }
    
    NSString *appFile = [documentsDirectory stringByAppendingPathComponent:fileName];
    
    return [data writeToFile:appFile atomically:YES];
}

+ (id)applicationPlistFromFile:(NSString *)fileName {
    
    NSData *retData;
    NSError *error;
    id retPlist;
    NSPropertyListFormat format;
    
    retData = [self applicationDataFromFile:fileName];
    
    if (!retData) {
        NSLog(@"Data file not returned.");
        return nil;
    }
    
    retPlist = [NSPropertyListSerialization propertyListWithData:retData options:NSPropertyListImmutable format:&format error:&error];
    
    if (!retPlist){
        NSLog(@"Plist not returned, error: %@", error);
        return nil;
    }
    
    //    NSLog(@"Saves settings value plist : %@",retPlist);
    
    return retPlist;
}

+ (NSData *)applicationDataFromFile:(NSString *)fileName {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *appFile = [documentsDirectory stringByAppendingPathComponent:fileName];
    NSData *myData = [[NSData alloc] initWithContentsOfFile:appFile];
    return myData;
}

+(void)removeSettingFile{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:FILENAME_LIB_SETTINGS_PLIST];
    
    NSError *error;
    if(![[NSFileManager defaultManager] removeItemAtPath:path error:&error])
    {
        NSLog(@"plist setting file remove complete");
    }
    
}


+(NSMutableDictionary*)checkSettingFileAndRead{
    
    NSMutableDictionary *settingDict = [NSMutableDictionary new];
    
    id setting = [self applicationPlistFromFile:FILENAME_LIB_SETTINGS_PLIST];
    
    if (!setting){
        //파일없어서 저장 시도
        [self writeApplicationPlist:settingDict toFile:FILENAME_LIB_SETTINGS_PLIST];
    } else {
        //로드 완료
        settingDict = [NSMutableDictionary dictionaryWithDictionary:setting];
    }
    
    
    return settingDict;
    
}

+ (id)libSettingObjectForKey:(NSString *)key {
    
    NSMutableDictionary *settingDict = [self checkSettingFileAndRead];
    
    NSLog(@"libSettingObjectForKey:%@ = %@",key,[settingDict valueForKey:key]);
    
    return [settingDict valueForKey:key];
    
}

+ (void)setLibSettingObject:(id)object forKey:(NSString *)key {
    
    NSMutableDictionary *settingDict = [self checkSettingFileAndRead];
    
    NSLog(@"setLibSettingObject:%@ <= %@",key,object);
    
    [settingDict setObject:object forKey:key];
    
    [self writeApplicationPlist:settingDict toFile:FILENAME_LIB_SETTINGS_PLIST];
    
}

+ (void)removeLibSettingObjectForKey:(NSString *)key {
    
    NSMutableDictionary *settingDict = [self checkSettingFileAndRead];
    
    NSLog(@"removeLibSettingObjectForKey:%@",key);
    
    [settingDict removeObjectForKey:key];
    
    [self writeApplicationPlist:settingDict toFile:FILENAME_LIB_SETTINGS_PLIST];
    
}

#pragma mark - UserDefault
//NSUserDefaults 버전 , Xcode 8 + 특정기기 조합에서 NSUserDefaults 가 유실되는 케이스로, 라이브러리 세팅은 plist 파일을 따로 가져가기로 했다.
+ (id)userDefaultObjectForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] objectForKey:key];
}

+ (void)setUserDefaultObject:(id)object forKey:(NSString *)key {
    [[NSUserDefaults standardUserDefaults] setObject:object forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (void)removeUserDefaultObjectForKey:(NSString *)key {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+(BOOL)getObjectBoolValue:(id)obj{
    NSLog(@"object bool value??? : %@ (1 is YES)",obj);
    if (obj != nil){
        return [obj boolValue];
    } else {
        return NO;
    }
}


@end
