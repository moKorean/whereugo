//
//  Network.h
//  whereugo
//
//  Created by mo.o on 2018. 5. 3..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class AFHTTPSessionManager;

typedef NS_ENUM(NSUInteger, NetworkMethod) {
    GET = 100,
    POST,
    PUT,
    PATCH,
    DELETE,
    OPTIONS,
    HEAD,
    TRACE,
    CONNECT,
};
#define ST_NetworkMethodStr(enum) [@[@"GET",@"POST",@"PUT",@"PATCH",@"DELETE",@"OPTIONS",@"HEAD",@"TRACE",@"CONNECT"] objectAtIndex:enum-100]

typedef NS_ENUM(NSUInteger, RequestType) {
    JSON,
    NORMAL
};


@interface Network : NSObject

@property (nonatomic, strong) UIActivityIndicatorView * _Nullable spinner;
@property (nonatomic, strong) UIView * _Nullable maskedView;


/**
 @brief 네트워크 싱글턴 객체를 리턴합니다.
 @return Network
 */
+ (nonnull instancetype)sharedNetwork;

/**
 싱글 세션메니저를 리턴합니다. 웹뷰등에서 사용하기위해 세팅할때 여기서 가져옵니다.
 */
- (nonnull AFHTTPSessionManager*)sessionManager;


#pragma mark - public
/*
 @breif 서버 호스트를 설정합니다. 설정하고 나면 네트워크객체의 싱글턴 세션이 새로 시작됩니다.
 배열로 넣습니다.
 앱의 최초에 한번 설정해주세요. e.g.) @"http://123.456.789.012:3456",@"http://123.456.789.012:3456"
 */
- (void)setServerHost:(nonnull NSString*)host;



/**
 @brief 세션객체를 받아올수 있습니다.
 @return NSURLSession
 */
- (nonnull NSURLSession*)session;

/**
 @brief API Host 에 대한 세션ID를 가져옵니다.
 */
- (nullable NSString*)sessionId;


/**
 @brief 현재 네트워크가 사용가능한지
 @return 가능여부
 */
- (BOOL)isNetworkAvailable;


/**
 @brief 데이타 네트워크 사용 가능한지
 @return 가능여부
 */
- (BOOL)isDataNetworkAvailable;


/**
 @brief 와이파이 사용가능한지
 @return 가능여부
 */
- (BOOL)isWifiAvailable;

/**
 @brief reachability start
 */
- (void)startReachabilityStartWithCompletion:(nullable void (^)(void))completion;


- (nullable NSURLSessionDataTask *)requestUrlConnectionWithMethod:(NetworkMethod)method
                                                     url:(nonnull NSString*)url
                                              parameters:(nullable NSDictionary *)parameters
                                                 success:(nullable void (^)(NSDictionary* _Nonnull responseDictionary, NSURLSessionDataTask* _Nullable task))success
                                                 failure:(nullable void (^)(NSDictionary* _Nullable errResponseDictionary, NSError* _Nonnull error, long httpStatusCode, NSURLSessionDataTask* _Nullable task))failure
                                                progress:(nullable void (^)(NSProgress* _Nullable progress))progress;


- (nullable NSURLSessionDataTask *)requestUrlConnectionWithMethod:(NetworkMethod)method
                                                      requestType:(RequestType)rType
                                                              url:(nonnull NSString*)url
                                                       parameters:(nullable NSDictionary *)parameters
                                             customRequestHeaders:(nullable NSDictionary*)customReqHeaders
                                                          success:(nullable void (^)(NSDictionary* _Nonnull responseDictionary, NSURLSessionDataTask* _Nullable task))success
                                                          failure:(nullable void (^)(NSDictionary* _Nullable errResponseDictionary, NSError* _Nonnull error, long httpStatusCode, NSURLSessionDataTask* _Nullable task))failure
                                                         progress:(nullable void (^)(NSProgress* _Nullable progress))progress;




/**
 @breif 세션과 세션단위로 저장되는 암호화 키 등을 삭제하고 새로운 세션을 열어둡니다. 로그아웃할때 사용해주세요~
 */
- (void)sessionInvalidate;



#pragma mark API Connector

- (void)authToBmw;

- (BOOL)isReadyToSendToCar;

-(void)sendToCarSbj:(NSString*_Nullable)sbj Msg:(NSString*_Nullable)msg Lat:(NSString*_Nonnull)lat lng:(NSString*_Nonnull)lng;


#pragma mark util

-(void)loadingStart;
-(void)loadingEnd;


@end

