//
//  SubUINavigationController.m
//  whereugo
//
//  Created by mo.o on 2018. 5. 14..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import "SubUINavigationController.h"
#import "ResultDetailTableViewController.h"

@interface SubUINavigationController ()

@end

@implementation SubUINavigationController
@synthesize poiMeta;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSLog(@"SubUINavigationController vide did load!! data : %ld",[poiMeta count]);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
/*
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if ([[segue destinationViewController] isKindOfClass:[ResultDetailTableViewController class]]){
        NSLog(@"going to ResultDetailTableViewController");
        
        ((ResultDetailTableViewController*)[segue destinationViewController]).poiMeta = [poiMeta copy];
        
    } else {
        NSLog(@"going to others");
    }
    
}
*/

@end
