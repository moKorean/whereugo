//
//  LibUtils.h
//  whereugo
//
//  Created by mo.o on 2018. 5. 3..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LibUtils : NSObject

#pragma mark - Library Utils


+ (int)str:(NSString*)source indexOf:(NSString *)text;

/**
 * @breif 시뮬레이터인지 체크합니다.
 */
+ (BOOL)isRealDevice;


/**
 * @breif yyyyMMddHHmmss 형태의 지금 시간을 가져온다.
 */
+ (NSString*)getTimeStr;


/*
 @breif OS의 메이저 버전을 가져옵니다.
 @return e.g.) iOS9.x 면 -> 9, iOS8.x 면 -> 8
 */
+ (NSString*)getOSMajorVer;

/*
 @breif 스트링이 NIL 또는 비어있는지 체크
 @return 비거나 NIL이면 true
 */
+(BOOL)isStringNilOrEmpty:(NSString*)aString;

#pragma mark - Encoding, Conversion

//Dictionary & Data
/*
 @breif 딕셔너리를 데이터로 바꿉니다.
 */
+ (NSData*)dictionaryToData:(NSDictionary*)myDictionary;

/*
 @breif 데이터를 딕셔너리로 바꿉니다.
 */
+ (NSDictionary*)dataToDictionary:(NSData*)myData;

//HEX & Data
/*
 @breif 데이터를 헥스코드로 바꿉니다.
 */
+ (NSString *)NSDataToHex:(NSData *)data;

/*
 @breif 헥스코드를 데이터로 바꿉니다.
 */
+ (NSData *) HexToNSData:(NSString*)hexString;

//base64
/*
 @breif 스트링을 base64 디코딩합니다.
 */
+ (NSData *)base64_decode:(NSString *)str;

/*
 @breif 데이터를 base64 인코딩합니다.
 */
+ (NSString *)base64_encode_data:(NSData *)data;


#pragma mark - UserDefault

/*
 @breif NSUserDefaults standardUserDefaults 에서 해당하는 키의 오브제를 꺼내옵니다.
 */
+ (id)userDefaultObjectForKey:(NSString *)key;

/*
 @breif NSUserDefaults standardUserDefaults 에서 키에 오브제를 저장합니다.
 */
+ (void)setUserDefaultObject:(id)object forKey:(NSString *)key;

/*
 @breif NSUserDefaults standardUserDefaults 에서 키에 해당하는 키,밸류를 삭제합니다.
 */
+ (void)removeUserDefaultObjectForKey:(NSString *)key;


//plist 3형제
+ (id)libSettingObjectForKey:(NSString *)key; //가져오기
+ (void)setLibSettingObject:(id)object forKey:(NSString *)key; //넣어주기
+ (void)removeLibSettingObjectForKey:(NSString *)key; //지워주기

+ (UIViewController*)getRootViewController;



@end
