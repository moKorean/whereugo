//
//  ResultDetailTableViewController.h
//  whereugo
//
//  Created by mo.o on 2018. 5. 14..
//  Copyright © 2018년 mo.o. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultDetailTableViewController : UITableViewController <UITableViewDelegate, UITableViewDataSource>{

}

@property (strong, nonatomic) NSMutableDictionary* poiMeta;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *backButton;

@property (strong, nonatomic) IBOutlet UITableView* resultTableView;

@end
